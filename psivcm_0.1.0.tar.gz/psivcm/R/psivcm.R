likelihood <- function(Y, rs, family){

  if(family == "gaussian") return(sum((Y - rs) ^ 2))
  if(family == "cox") return(- sum(Y[, 2] * (rs - log(rev(cumsum(rev(exp(rs))))))))

}


psivcm <- function(Y, X, U, Z, lambda, family, maxit = 100, tol = 1e-5, display = TRUE, beta0, coef0, degree, knots, Boundary.knots, gm){

  # Order data by sorting the observed time
  if(family == "cox"){
    ord <- order(Y[, 1], - Y[, 2])
    Y <- Y[ord, ]
    X <- X[ord, ]
    U <- U[ord, ]
    Z <- Z[ord, ]
  }

  n <- nrow(X)
  p <- ncol(X)
  q <- ncol(U)
  r <- ncol(Z)
  d <- length(knots) + degree

  gamma.loc <- which(sort(c(rep(seq(2, p * 2, by = 2), each = d), seq(1, p * 2, by = 2))) %% 2 != 0)
  alpha.loc <- which(sort(c(rep(seq(2, p * 2, by = 2), each = d), seq(1, p * 2, by = 2))) %% 2 == 0)
  if(family == "gaussian"){
    gamma.loc <- gamma.loc + 1
    alpha.loc <- alpha.loc + 1
  }

  # Initialization
  converge <- FALSE
  beta.converge <- FALSE
  beta1 <- beta0
  coef1 <- coef0
  gamma <- coef1[gamma.loc]
  alpha <- coef1[alpha.loc]
  rho <- 0

  # Update beta and g iteratively
  for(it in 1:maxit){

    beta0 <- beta1
    coef0 <- coef1

    for(loop in 1:100){

      # Approximate the varying coefficients using B-spline basis functions with the updated beta
      bSpline.obj <- bSpline.ori(U %*% beta1, knots = knots, Boundary.knots = Boundary.knots)
      B <- bSpline.obj$B
      data <- cbind(X, Z, B)
      if(family == "gaussian") data <- cbind(1, data)
      d1B <- bSpline.obj$deriv1
      d2B <- bSpline.obj$deriv2
      g <- matrix(rep(gamma, each = n), nrow = n, ncol = p)
      g <- sapply(1:p, function(i) g[, i] + B %*% alpha[((i - 1) * d + 1):(i * d)])
      g <- cbind(g, matrix(tail(coef1, r + d), nrow = n, ncol = r + d, byrow = T))
      if(family == "gaussian") g <- cbind(coef1[1], g)
      d1g <- sapply(1:p, function(i) d1B %*% alpha[((i - 1) * d + 1):(i * d)])
      d2g <- sapply(1:p, function(i) d2B %*% alpha[((i - 1) * d + 1):(i * d)])
      eta <- rowSums(g * data)

      # Update beta with fixed g
      if(family == "gaussian"){

        d1eta <- (rowSums(d1g * X) + rowSums(t(t(d1B) * tail(coef1, d)))) * U
        d1l <- - 2 * colSums((Y - eta) * d1eta)
        if(all(d1l == 0) | any(is.na(d1l))) break
        d2gXpsiB <- (rowSums(d2g * X) + rowSums(t(t(d2B) * tail(coef1, d))))
        d2l <- 2 * Reduce("+", lapply(1:n, function(x) tcrossprod(d1eta[x, ]) - (Y[x] - eta[x]) * d2gXpsiB[x] * tcrossprod(U[x, ])))

      } else if(family == "cox"){

        # Compute the first derivative of the likelihood with respect to beta
        d1eta <- (rowSums(d1g * X) + rowSums(t(t(d1B) * tail(coef1, d)))) * U
        expeta <- exp(eta)
        d1l.com2.num <- sapply(1:q, function(x) rev(cumsum(rev((d1eta * expeta)[, x]))))
        d1l.com2.denom <- rev(cumsum(rev(expeta)))
        d1l <- - colSums(Y[, 2] * (d1eta - d1l.com2.num / d1l.com2.denom))
        if(all(d1l == 0) | any(is.na(d1l))) break

        # Compute the second derivative of the likelihood with respect to beta
        d2gXpsiB <- (rowSums(d2g * X) + rowSums(t(t(d2B) * tail(coef1, d))))
        d2eta <- lapply(1:n, function(x) d2gXpsiB[x] * tcrossprod(U[x, ]))
        d1l.com2.num1 <- lapply(1:n, function(x) (d2eta[[x]] + tcrossprod(d1eta[x, ])) * expeta[x])
        d1l.com2.num1.cumsum <- rev(Reduce("+", rev(d1l.com2.num1), accumulate = TRUE))
        d2l <- - Reduce("+", lapply(which(Y[, 2] == 1), function(x) (d2eta[[x]] - d1l.com2.num1.cumsum[[x]] / d1l.com2.denom[x] + (d1l.com2.num[x, ] / d1l.com2.denom[x] / d1l.com2.denom[x]) %*% t(d1l.com2.num[x, ]))))
      }

      S <- c(beta1, rho) - solve(rbind(cbind(d2l + diag(rho, nrow = q, ncol = q), beta1), cbind(2 * t(beta1), 0)), tol = 1e-100) %*% c(d1l + rho * beta1, beta1 %*% beta1 - 1)

      if(sqrt((as.numeric(tail(S, 1)) - rho) ^ 2) + sqrt(sum((c(head(S, q)) - beta1) ^ 2)) < tol){

        beta.converge <- TRUE
        rho <- as.numeric(tail(S, 1))
        beta1 <- c(head(S, q))
        break

      }

      rho <- as.numeric(tail(S, 1))
      beta1 <- c(head(S, q))
    }

    # Update the regression coefficients with fixed beta
    B <- bSpline.ori(U %*% beta1, knots = knots, Boundary.knots = Boundary.knots)$B
    data <- cbind(X[, rep(1:p, each = nknot - 1 + degree)] * cbind(rep(1, n), B)[, rep(1:(nknot - 1 + degree), p)], Z, B)
    group.multiplier <- rep(c(1, lambda[2] / lambda[1]), p)
    if(missing(gm)) gm <- rep(1, p)
    group.multiplier <- group.multiplier / rep(gm, each = 2)
    if(family == "gaussian"){
      fit <- grpreg::grpreg(data, Y, group = c(sort(c(rep(seq(2, p * 2, by = 2), each = d), seq(1, p * 2, by = 2))), rep(0, r + d)), lambda = lambda[1], group.multiplier = group.multiplier, max.iter = 100000)
    } else if(family == "cox"){
      fit <- grpreg::grpsurv(data, Y, group = c(sort(c(rep(seq(2, p * 2, by = 2), each = d), seq(1, p * 2, by = 2))), rep(0, r + d)), lambda = rep(lambda[1], 2), group.multiplier = group.multiplier, max.iter = 100000)
    }
    coef1 <- fit$beta[, 1]
    gamma <- coef1[gamma.loc]
    alpha <- coef1[alpha.loc]

    diff <- sqrt(sum((beta0 - beta1) ^ 2)) + sqrt(sum((coef0 - coef1) ^ 2))

    if(display == TRUE) print(c(diff, beta1))

    if(((it != 1) & (diff < tol)) | it == maxit){

      if(!beta.converge) warning("beta estimation: ran out of iterations and did not converge", immediate. = TRUE)
      if(round(sum(beta1 ^ 2), 5) != 1) stop("Norm 1 constraint is violated")
      if(diff < tol) converge <- TRUE

      # Compute the likelihood with updated beta and g
      g <- matrix(rep(gamma, each = n), nrow = n, ncol = p)
      g <- sapply(1:p, function(i) g[, i] + B %*% alpha[((i - 1) * d + 1):(i * d)])
      g <- cbind(g, matrix(tail(coef1, r + d), nrow = nrow(g), ncol = r + d, byrow = T))
      if(family == "gaussian"){
        g <- cbind(coef1[1], g)
        l <- likelihood(Y, diag(tcrossprod(g, cbind(1, X, Z, B))), family)
      } else if(family == "cox") l <- likelihood(Y, diag(tcrossprod(g, cbind(X, Z, B))), family)
      df <- fit$df[1]

      break
    }
  }
  list(beta = beta1, g = g, coef = coef1, l = l, lambda = lambda, df = df, converge = converge)
}


setup.grlambda <- function(X, Y, family, group = 1:ncol(X), nlambda = 100, lambda.min.ratio, penalty.factor, offset = rep(0, length(Y))){

  n <- length(Y)
  p <- ncol(X)
  K <- length(unique(group))

  if(family == "cox"){
    ord <- order(Y[, 1], - Y[, 2])
    X <- X[ord, ]
    offset <- as.matrix(offset)[ord, ]
    Y <- Y[ord, ]
  }

  # Standardize X prior to orthogonalization and center the response for linear model.
  X <- apply(X, 2, function(x) (x - mean(x)) / sqrt(sum((x - mean(x)) ^ 2) / n))
  if(family == "gaussian") Y <- Y - mean(Y)

  if(missing(penalty.factor)) penalty.factor <- sqrt(table(group))

  # Function to perform orthogonalization from the R package "grpreg"
  orthogonalize <- function(X, group) {

    n <- nrow(X)
    J <- max(group)
    T <- vector("list", J)
    XX <- matrix(0, nrow = nrow(X), ncol = ncol(X))
    XX[, which(group == 0)] <- X[, which(group == 0)]
    for (j in seq_along(integer(J))) {
      ind <- which(group == j)
      if (length(ind) == 0) next
      SVD <- svd(X[, ind, drop = FALSE], nu = 0)
      r <- which(SVD$d > 1e-10)
      T[[j]] <- sweep(SVD$v[, r, drop = FALSE], 2, sqrt(n) / SVD$d[r], "*")
      XX[, ind[r]] <- X[, ind] %*% T[[j]]
    }
    nz <- !apply(XX == 0, 2, all)
    XX <- XX[, nz, drop = FALSE]
    attr(XX, "T") <- T
    attr(XX, "group") <- group[nz]
    XX

  }

  X.ortho <- orthogonalize(X, group)

  if(family == "gaussian"){

    if(any(group == 0)){
      r <- lm((Y - offset) ~ X.ortho[, group == 0])$residual
    } else r <- Y - offset
    vec <- vector(length = K)
    for(j in 1:K){
      J <- which(group == unique(group)[j])
      zj <- as.numeric(crossprod(X.ortho[, J], r)) / n
      vec[j] <- sqrt(as.numeric(crossprod(zj, zj)))
    }
    if(any(group == 0)){
      lambda.max <- max((vec / penalty.factor)[- which(unique(group) == 0)])
    } else {
      lambda.max <- max(vec / penalty.factor)
    }

  } else if(family == "cox"){

    if(any(group == 0)){
      all.eta <- exp(X.ortho[, group == 0] %*% coxph(Y ~ X.ortho[, group == 0])$coef)
    } else all.eta <- exp(rep(0, n))
    if(!missing(offset)){
      all.eta <- all.eta * exp(offset)
    }
    totjump <- length(unique(Y[Y[, 2] == 1, 1]))
    A <- matrix(0, totjump, n)
    B <- matrix(0, totjump, n)
    cum.eta <- c(rev(cumsum(rev(all.eta))), 0)
    eta.atrisk <- cum.eta[1]
    k <- 0
    w <- rep(0, n)
    z <- rep(0, n)
    Y.tmp <- Y[Y[, 2] == 1, 1]
    nofail <- table(Y.tmp)[match(Y.tmp, names(table(Y.tmp)))]
    for (i in 1:n) {
      if (i == 1) temp <- 0 else temp <- Y[i - 1, 1]
      if (Y[i, 2] == 1 & Y[i, 1] > temp) {
        A[k + 1, i:n] <- ((all.eta[i:n] * eta.atrisk - all.eta[i:n] ^ 2) / eta.atrisk ^ 2) * nofail[k + 1]
        B[k + 1, i:n] <- nofail[k + 1] * all.eta[i:n] / eta.atrisk
        k <- k + 1
      }
      w[i] <- sum(A[1:k, i])
      z[i] <- (Y[i, 2] - sum(B[1:k, i])) / (w[i] + as.integer(abs(w[i]) < 1e-8))
      eta.atrisk <- cum.eta[i + 1]
    }
    vec <- vector(length = K)
    for(j in 1:K){
      if(unique(group)[j] == 0){
        vec[j] <- NA
        next
      }
      J <- which(group == unique(group)[j])
      zj <- crossprod(X.ortho[, J], w * z) / n
      vec[j] <- sqrt(crossprod(zj, zj))
    }
    if(any(group == 0)){
      lambda.max <- max(vec[!is.na(vec)] / penalty.factor[- which(unique(group) == 0)])
    } else {
      lambda.max <- max(vec[!is.na(vec)] / penalty.factor)
    }

  }

  if(missing(lambda.min.ratio)) lambda.min.ratio <- ifelse(n > p, 0.001, 0.05)
  lambda.min <- lambda.min.ratio * lambda.max

  c(lambda.max * (lambda.min / lambda.max) ^ (seq(0, nlambda, length = nlambda) / nlambda))
}


bSpline.ori <- function(x, knots = 0, Boundary.knots){

  names(x) <- paste(1:length(x), sep = "")
  if(length(knots) + 2 == 3){

    a <- Boundary.knots[1]
    b <- knots
    c <- Boundary.knots[2]
    N <- splines2::bSpline(x[x >= b], degree = 2, Boundary.knots = c(b, c))
    N.deriv1 <- splines2::dbs(x[x >= b], degree = 2, Boundary.knots = c(b, c), derivs = 1)
    N.deriv2 <- splines2::dbs(x[x >= b], degree = 2, Boundary.knots = c(b, c), derivs = 2)
    B <- splines2::bSpline(a + b - x[x < b], degree = 2, Boundary.knots = c(a, b))
    B.deriv1 <- - splines2::dbs(a + b - x[x < b], degree = 2, Boundary.knots = c(a, b), derivs = 1)
    B.deriv2 <- splines2::dbs(a + b - x[x < b], degree = 2, Boundary.knots = c(a, b), derivs = 2)
    comb.B <- matrix(nrow = length(x), ncol = 3)
    for(i in 1:length(x)) if(x[i] < b) comb.B[i, ] <- c(B[names(x)[i], 1], B[names(x)[i], 2], 0) else comb.B[i, ] <- c(N[names(x)[i], 1] * (c - b) / (a - b), 0, N[names(x)[i], 2])
    comb.deriv1 <- matrix(nrow = length(x), ncol = 3)
    for(i in 1:length(x)) if(x[i] < b) comb.deriv1[i, ] <- c(B.deriv1[names(x)[i], 1], B.deriv1[names(x)[i], 2], 0) else comb.deriv1[i, ] <- c(N.deriv1[names(x)[i], 1] * (c - b) / (a - b), 0, N.deriv1[names(x)[i], 2])
    comb.deriv2 <- matrix(nrow = length(x), ncol = 3)
    for(i in 1:length(x)) if(x[i] < b) comb.deriv2[i, ] <- c(B.deriv2[names(x)[i], 1], B.deriv2[names(x)[i], 2], 0) else comb.deriv2[i, ] <- c(N.deriv2[names(x)[i], 1] * (c - b) / (a - b), 0, N.deriv2[names(x)[i], 2])

  } else if(length(knots) + 2 == 5){

    a <- Boundary.knots[1]
    b <- knots[1]
    c <- knots[2]
    d <- knots[3]
    e <- Boundary.knots[2]
    N <- splines2::bSpline(x[x >= c], degree = 2, knots = d, Boundary.knots = c(c, e))
    N.deriv1 <- splines2::dbs(x[x >= c], degree = 2, knots = d, Boundary.knots = c(c, e), derivs = 1)
    N.deriv2 <- splines2::dbs(x[x >= c], degree = 2, knots = d, Boundary.knots = c(c, e), derivs = 2)
    B <- splines2::bSpline(a + c - x[x < c], degree = 2, knots = b, Boundary.knots = c(a, c))
    B.deriv1 <- - splines2::dbs(a + c - x[x < c], degree = 2, knots = b, Boundary.knots = c(a, c), derivs = 1)
    B.deriv2 <- splines2::dbs(a + c - x[x < c], degree = 2, knots = b, Boundary.knots = c(a, c), derivs = 2)
    comb.B <- matrix(nrow = length(x), ncol = 5)
    for(i in 1:length(x)) if(x[i] < c) comb.B[i, ] <- c(B[names(x)[i], 1], B[names(x)[i], 2], B[names(x)[i], 3], 0, 0) else comb.B[i, ] <- c((d - c) / (a - b) * N[names(x)[i], 1], 0, 0, N[names(x)[i], 2], N[names(x)[i], 3])
    comb.deriv1 <- matrix(nrow = length(x), ncol = 5)
    for(i in 1:length(x)) if(x[i] < c) comb.deriv1[i, ] <- c(B.deriv1[names(x)[i], 1], B.deriv1[names(x)[i], 2], B.deriv1[names(x)[i], 3], 0, 0) else comb.deriv1[i, ] <- c((d - c) / (a - b) * N.deriv1[names(x)[i], 1], 0, 0, N.deriv1[names(x)[i], 2], N.deriv1[names(x)[i], 3])
    comb.deriv2 <- matrix(nrow = length(x), ncol = 5)
    for(i in 1:length(x)) if(x[i] < c) comb.deriv2[i, ] <- c(B.deriv2[names(x)[i], 1], B.deriv2[names(x)[i], 2], B.deriv2[names(x)[i], 3], 0, 0) else comb.deriv2[i, ] <- c((d - c) / (a - b) * N.deriv2[names(x)[i], 1], 0, 0, N.deriv2[names(x)[i], 2], N.deriv2[names(x)[i], 3])

  }
  list(B = comb.B, deriv1 = comb.deriv1, deriv2 = comb.deriv2)
}


get.g <- function(X, U, Z, B, family, beta, coef){

  n <- nrow(X)
  p <- ncol(X)
  r <- ncol(Z)
  d <- ncol(B)
  gamma.loc <- which(sort(c(rep(seq(2, p * 2, by = 2), each = d), seq(1, p * 2, by = 2))) %% 2 != 0)
  alpha.loc <- which(sort(c(rep(seq(2, p * 2, by = 2), each = d), seq(1, p * 2, by = 2))) %% 2 == 0)
  if(family == "gaussian"){
    gamma <- coef[gamma.loc + 1]
    alpha <- coef[alpha.loc + 1]
  } else if(family == "cox"){
    gamma <- coef[gamma.loc]
    alpha <- coef[alpha.loc]
  }
  g <- matrix(rep(gamma, each = n), nrow = n, ncol = p)
  g <- sapply(1:p, function(i) g[, i] + B %*% alpha[((i - 1) * d + 1):(i * d)])
  g <- cbind(g, matrix(tail(coef, r + d), nrow = n, ncol = r + d, byrow = T))
  if(family == "gaussian") g <- cbind(coef[1], g)

  g
}


gen.data <- function(seed, n, p, q, beta, psi, family, exp.rate, model){

  set.seed(seed)
  X <- matrix(rnorm(n * p), nrow = n, ncol = p)
  U <- matrix(rnorm(n * q), nrow = n, ncol = q)
  ind <- U %*% beta
  Z <- U
  if(model == 3){
    Z[, 1] <- 0.5 * U[, 1] ^ 2 + 0.8 * U[, 1]
    Z[, 2] <- 0.5 * U[, 2] ^ 2 + 0.8 * U[, 2]
    Z[, 3] <- - 0.3 * U[, 3] ^ 2 + 0.8 * U[, 3]
    Z[, 4] <- - 0.3 * U[, 4] ^ 2 + 0.8 * U[, 4]
  }
  ind <- U %*% beta

  # Generate coefficient functions
  g1 <- function(z) - 0.5 + 0 * z
  g2 <- function(z) - 0.4 + 0 * z
  g3 <- function(z) - 0.3 + 0 * z
  g4 <- function(z) - 0.2 + 0 * z
  g5 <- function(z) - 0.1 + 0 * z
  g6 <- function(z) 0.1 + 0 * z
  g7 <- function(z) 0.2 + 0 * z
  g8 <- function(z) 0.3 + 0 * z
  g9 <- function(z) 0.4 + 0 * z
  g10 <- function(z) 0.5 + 0 * z
  if(model == 2) {
    g11 <- function(z) - 0.5 + 0 * z
    g12 <- function(z) - 0.4 + 0 * z
    g13 <- function(z) - 0.3 + 0 * z
    g14 <- function(z) - 0.2 + 0 * z
    g15 <- function(z) - 0.1 + 0 * z
    g16 <- function(z) 0.1 + 0 * z
    g17 <- function(z) 0.2 + 0 * z
    g18 <- function(z) 0.3 + 0 * z
    g19 <- function(z) 0.4 + 0 * z
    g20 <- function(z) 0.5 + 0 * z
  } else {
    g11 <- function(z) 0.25 * z + 0 * z ^ 2
    g12 <- function(z) - 0.2 - 0.3 * z + 0 * z ^ 2
    g13 <- function(z) - 0.25 * z ^ 2
    g14 <- function(z) -0.2 + 0.25 * z ^ 2
    g15 <- function(z) 0.4 * z - 0.1 * z ^ 2
    g16 <- function(z) - 0.3 + 0.3 * z + 0.2 * z ^ 2
    g17 <- function(z) 0.1 * z ^ 3
    g18 <- function(z) - 0.2 - 0.15 * z ^ 3
    g19 <- function(z) 1 / (1 + exp(- z * 5))
    g20 <- function(z) 1 / (1 + exp(z * 4)) - 0.3
  }

  g <- matrix(0, nrow = n, ncol = p)
  g[, 1:20] <- sapply(1:20, function(i) do.call(paste("g", i, sep = ""), list(ind)))
  g <- cbind(g, matrix(psi, nrow = n, ncol = q, byrow = TRUE))
  if (family == "gaussian") {
    if(model == 4) {
      epsilon <- rnorm(n, sd = sqrt(2))
    } else {
      epsilon <- rnorm(n)
    }
    Y <- sapply(1:n, function(x) g[x, ] %*% c(X[x, ], Z[x, ])) + epsilon
  } else if (family == "cox") {
    u <- runif(n)
    t <- sqrt(- 2 * log(u) * exp(- sapply(1:n, function(x) g[x, ] %*% c(X[x, ], Z[x, ]))))
    if(missing(exp.rate)){
      y <- t
      delta <- rep(1, n)
    } else {
      C <- rexp(n, rate = exp.rate)
      y <- sapply(1:n, function(i) min(C[i], t[i]))
      delta <- C > t
    }
    Y <- Surv(y, delta)
  }

  return(list(Y = Y, X = X, U = U, Z = Z, g = g))
}
